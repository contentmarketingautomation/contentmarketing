.. Content Marketing Automation documentation master file, created by
   sphinx-quickstart on Thu Nov  7 23:36:08 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Content Marketing Automation's documentation!
========================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
